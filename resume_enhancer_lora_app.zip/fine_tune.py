
from transformers import AutoTokenizer, AutoModelForCausalLM, Trainer, TrainingArguments
from datasets import load_dataset
from peft import LoraConfig, get_peft_model

model_id = "distilgpt2"
tokenizer = AutoTokenizer.from_pretrained(model_id)
tokenizer.pad_token = tokenizer.eos_token
model = AutoModelForCausalLM.from_pretrained(model_id)

dataset = load_dataset("json", data_files="data.json", split="train")

def tokenize(batch):
    return tokenizer(batch["text"], truncation=True, padding="max_length", max_length=64)

dataset = dataset.map(tokenize)

lora_config = LoraConfig(
    r=8,
    lora_alpha=32,
    target_modules=["c_attn"],
    lora_dropout=0.05,
    bias="none",
    task_type="CAUSAL_LM"
)

model = get_peft_model(model, lora_config)

training_args = TrainingArguments(
    output_dir="./resume-lora-model",
    per_device_train_batch_size=1,
    num_train_epochs=4,
    learning_rate=2e-4,
    logging_dir="./logs",
    logging_steps=1,
    save_total_limit=1,
    save_steps=5,
    overwrite_output_dir=True
)

trainer = Trainer(model=model, args=training_args, train_dataset=dataset)
trainer.train()
trainer.save_model("./resume-lora-model")
tokenizer.save_pretrained("./resume-lora-model")
