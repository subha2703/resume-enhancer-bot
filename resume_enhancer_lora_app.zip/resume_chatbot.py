
import streamlit as st
from transformers import AutoTokenizer, AutoModelForCausalLM
from peft import PeftModel, PeftConfig
import PyPDF2

st.set_page_config(page_title="Resume Enhancer", layout="centered", page_icon="📄")
st.title("📄 Resume Enhancement Chatbot")

@st.cache_resource
def load_model():
    model_path = "./resume-lora-model"
    config = PeftConfig.from_pretrained(model_path)
    base_model = AutoModelForCausalLM.from_pretrained(config.base_model_name_or_path, local_files_only=True)
    tokenizer = AutoTokenizer.from_pretrained(model_path, local_files_only=True)
    tokenizer.pad_token = tokenizer.eos_token
    model = PeftModel.from_pretrained(base_model, model_path)
    return model, tokenizer

model, tokenizer = load_model()

def enhance_line(line):
    prompt = f"{line.strip()} -->"
    inputs = tokenizer(prompt, return_tensors="pt")
    outputs = model.generate(
        **inputs,
        max_new_tokens=100,
        num_return_sequences=1,
        do_sample=True,
        top_k=50,
        pad_token_id=tokenizer.eos_token_id
    )
    result = tokenizer.decode(outputs[0], skip_special_tokens=True)
    return result.split("-->")[-1].strip()

mode = st.radio("Choose Input Method:", ["📄 Upload PDF", "📝 Paste Text"])
lines = []

if mode == "📄 Upload PDF":
    uploaded_file = st.file_uploader("Upload your resume (PDF only)", type=["pdf"])
    if uploaded_file:
        pdf_reader = PyPDF2.PdfReader(uploaded_file)
        for page in pdf_reader.pages:
            text = page.extract_text()
            if text:
                lines.extend([line.strip() for line in text.split("\n") if line.strip()])
elif mode == "📝 Paste Text":
    raw_text = st.text_area("Paste your resume text here (one item per line):", height=250)
    if raw_text:
        lines = [line.strip() for line in raw_text.split("\n") if line.strip()]

if lines:
    st.markdown("### 🔍 Enhanced Resume Lines")
    enhanced_results = []
    for line in lines:
        enhanced = enhance_line(line)
        enhanced_results.append((line, enhanced))
        st.markdown(f"**🔸 Original:** {line}\n\n✅ **Enhanced:** {enhanced}\n\n---")

    st.markdown("### 💾 Download Enhanced Resume")
    if st.button("📥 Generate Download File"):
        content = [f"Original: {orig}\nEnhanced: {enh}\n\n" for orig, enh in enhanced_results]
        with open("enhanced_resume.txt", "w", encoding="utf-8") as f:
            f.writelines(content)
        with open("enhanced_resume.txt", "rb") as f:
            st.download_button("⬇️ Download TXT", f, file_name="enhanced_resume.txt")
else:
    st.info("Please upload a PDF or paste text to begin.")
